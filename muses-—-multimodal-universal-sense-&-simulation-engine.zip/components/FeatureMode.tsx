
import React, { useRef, useState, useCallback, useEffect } from 'react';
import { 
  Camera, 
  Upload, 
  Play, 
  Brain, 
  Sparkles, 
  Loader2, 
  Info, 
  XCircle, 
  Code, 
  ChefHat, 
  Activity, 
  Target, 
  Palette, 
  ChevronRight, 
  ChevronLeft, 
  ArrowRight, 
  Braces, 
  Terminal,
  Cpu,
  Database,
  Hash,
  Box,
  Compass,
  Layers
} from 'lucide-react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'framer-motion';
import { analyzeScene, generateSpeech, playAudio } from '../services/geminiService';
import { AppMode, Theme } from '../types';
import { THEMES } from '../constants';

interface FeatureModeProps {
  mode: AppMode;
  theme: Theme;
  title: string;
  tagline: string;
  description: string;
  icon: React.ReactNode;
  color: string;
}

const TiltWrapper: React.FC<{ children: React.ReactNode; color: string }> = ({ children, color }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const rotateX = useTransform(y, [-300, 300], [15, -15]);
  const rotateY = useTransform(x, [-300, 300], [-15, 15]);

  function handleMouseMove(event: React.MouseEvent<HTMLDivElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;
    x.set(mouseX - width / 2);
    y.set(mouseY - height / 2);
  }

  function handleMouseLeave() {
    x.set(0);
    y.set(0);
  }

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: "preserve-3d",
        perspective: 1000,
      }}
      className="w-full h-full flex items-center justify-center p-8"
    >
      <motion.div
        style={{ transform: "translateZ(80px)", transformStyle: "preserve-3d" }}
        className="w-full max-w-lg aspect-square rounded-[3rem] border border-white/10 bg-white/5 backdrop-blur-xl flex flex-col items-center justify-center text-center p-12 relative group cursor-pointer overflow-hidden shadow-2xl"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        <div 
          className="absolute -inset-1 rounded-[3rem] blur-xl opacity-0 group-hover:opacity-20 transition-opacity duration-500"
          style={{ backgroundColor: color }}
        />
        {children}
      </motion.div>
    </motion.div>
  );
};

const FeatureMode: React.FC<FeatureModeProps> = ({ mode, theme, title, tagline, description, icon, color }) => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [showGame, setShowGame] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const colors = THEMES[theme];

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    setShowGame(false);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
        setError(null);
        startOverlayLoop();
      }
    } catch (err) {
      setError("Unable to access camera. Please check permissions.");
      console.error(err);
    }
  };

  const startOverlayLoop = () => {
    const render = (time: number) => {
      if (!overlayRef.current || !videoRef.current) return;
      const ctx = overlayRef.current.getContext('2d');
      if (!ctx) return;

      overlayRef.current.width = videoRef.current.videoWidth;
      overlayRef.current.height = videoRef.current.videoHeight;
      ctx.clearRect(0, 0, overlayRef.current.width, overlayRef.current.height);

      const pulse = (Math.sin(time / 250) + 1) / 2;
      const fastPulse = (Math.sin(time / 80) + 1) / 2;

      if (isCameraActive) {
        ctx.strokeStyle = `${color}44`;
        ctx.lineWidth = 1;
        const offset = 40;
        const len = 30;
        ctx.beginPath(); ctx.moveTo(offset, offset + len); ctx.lineTo(offset, offset); ctx.lineTo(offset + len, offset); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(overlayRef.current.width - offset - len, offset); ctx.lineTo(overlayRef.current.width - offset, offset); ctx.lineTo(overlayRef.current.width - offset, offset + len); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(offset, overlayRef.current.height - offset - len); ctx.lineTo(offset, overlayRef.current.height - offset); ctx.lineTo(offset + len, overlayRef.current.height - offset); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(overlayRef.current.width - offset - len, overlayRef.current.height - offset); ctx.lineTo(overlayRef.current.width - offset, overlayRef.current.height - offset); ctx.lineTo(overlayRef.current.width - offset, overlayRef.current.height - offset - len); ctx.stroke();
      }

      if (result) {
        if (mode === AppMode.INVENTOR && result.steps && result.steps[currentStep]) {
          const step = result.steps[currentStep];
          const ingredientIndex = step.relevant_ingredient_index;
          const ingredient = result.ingredients?.[ingredientIndex];

          if (ingredient && ingredient.box_2d) {
            const [ymin, xmin, ymax, xmax] = ingredient.box_2d;
            const left = (xmin / 1000) * overlayRef.current!.width;
            const top = (ymin / 1000) * overlayRef.current!.height;
            const width = ((xmax - xmin) / 1000) * overlayRef.current!.width;
            const height = ((ymax - ymin) / 1000) * overlayRef.current!.height;

            ctx.fillStyle = `${color}${Math.floor(pulse * 15).toString(16).padStart(2, '0')}`;
            ctx.fillRect(left, top, width, height);

            ctx.strokeStyle = color;
            ctx.lineWidth = 2 + (fastPulse * 2);
            ctx.beginPath();
            const sLen = 40 * pulse;
            ctx.moveTo(left, top + sLen); ctx.lineTo(left, top); ctx.lineTo(left + sLen, top);
            ctx.moveTo(left + width - sLen, top); ctx.lineTo(left + width, top); ctx.lineTo(left + width, top + sLen);
            ctx.moveTo(left + width, top + height - sLen); ctx.lineTo(left + width, top + height); ctx.lineTo(left + width - sLen, top + height);
            ctx.moveTo(left + sLen, top + height); ctx.lineTo(left, top + height); ctx.lineTo(left, top + height - sLen);
            ctx.stroke();

            ctx.setLineDash([5, 5]);
            ctx.strokeStyle = `${color}88`;
            ctx.beginPath();
            ctx.moveTo(overlayRef.current!.width / 2, overlayRef.current!.height);
            ctx.lineTo(left + width / 2, top + height / 2);
            ctx.stroke();
            ctx.setLineDash([]);

            ctx.fillStyle = color;
            ctx.font = 'bold 12px JetBrains Mono';
            ctx.textAlign = 'center';
            ctx.fillText(`TARGET: ${ingredient.name.toUpperCase()}`, left + width / 2, top - 15 - (pulse * 5));
          }
        }

        if (mode === AppMode.FUTURE && result.risks) {
           result.risks.forEach((risk: any) => {
            if (!risk.box_2d) return;
            const [ymin, xmin, ymax, xmax] = risk.box_2d;
            const left = (xmin / 1000) * overlayRef.current!.width;
            const top = (ymin / 1000) * overlayRef.current!.height;
            const width = ((xmax - xmin) / 1000) * overlayRef.current!.width;
            const height = ((ymax - ymin) / 1000) * overlayRef.current!.height;

            const baseColor = risk.severity === 'high' ? '#ef4444' : '#f59e0b';
            ctx.strokeStyle = baseColor;
            ctx.lineWidth = 3;
            ctx.strokeRect(left, top, width, height);
            ctx.fillStyle = baseColor;
            ctx.font = 'bold 14px Inter Tight';
            ctx.fillText(`${risk.label.toUpperCase()}`, left, top - 10);
          });
        }
      }

      animationFrameRef.current = requestAnimationFrame(render);
    };
    animationFrameRef.current = requestAnimationFrame(render);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = e.target?.result?.toString().split(',')[1];
        if (base64) {
          await analyzeFromBase64(base64);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeFromBase64 = async (base64: string) => {
    setIsAnalyzing(true);
    setResult(null);
    setShowGame(false);
    setCurrentStep(0);
    
    try {
      const response = await analyzeScene(base64, mode);
      setResult(response);

      let speechText = '';
      if (mode === AppMode.FUTURE) speechText = response.narration;
      if (mode === AppMode.COACH) speechText = response.feedback;
      if (mode === AppMode.WINGMAN) speechText = `Wingman suggestion: ${response.tips?.[0] || 'Observe closely.'}`;
      if (mode === AppMode.INVENTOR && response.recipeName) speechText = `I've synthesized ${response.recipeName}. Follow the AR instructions.`;
      
      if (speechText) {
        const audioB64 = await generateSpeech(speechText);
        if (audioB64) playAudio(audioB64);
      }
    } catch (err) {
      console.error(err);
      setError("Reality synchronization failed. Attempting reconnect...");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const captureAndAnalyze = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg');
      const base64 = dataUrl.split(',')[1];
      await analyzeFromBase64(base64);
    }
  };

  useEffect(() => {
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      stopCamera();
    };
  }, [stopCamera]);

  return (
    <div className="h-full flex flex-col gap-6">
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileUpload} 
        accept="image/*" 
        className="hidden" 
      />

      <div className="p-8 rounded-[2rem] border border-white/10 flex items-center justify-between shadow-2xl backdrop-blur-xl relative overflow-hidden"
           style={{ backgroundColor: colors.card, borderColor: colors.border }}>
        <div className="absolute top-0 right-0 p-4 opacity-5">
          <Brain size={120} />
        </div>
        <div className="flex items-center gap-6 relative z-10">
          <motion.div 
            whileHover={{ scale: 1.1, rotate: 5 }}
            className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg bg-gradient-to-br from-white/10 to-white/5 border border-white/10"
            style={{ color: color }}
          >
            {icon}
          </motion.div>
          <div>
            <h2 className="text-3xl font-black tracking-tight">{title}</h2>
            <p className="opacity-60 font-medium italic tracking-wide">{tagline} — {description}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 relative z-10">
           {!isCameraActive ? (
            <button 
              onClick={startCamera}
              className="px-8 py-4 rounded-xl font-black flex items-center gap-3 hover:scale-105 active:scale-95 transition-all shadow-xl uppercase tracking-widest text-xs"
              style={{ backgroundColor: color, color: colors.primary }}
            >
              <Camera size={18} /> Initialize Feed
            </button>
           ) : (
            <button 
              onClick={stopCamera}
              className="px-8 py-4 rounded-xl font-black flex items-center gap-3 bg-red-500/10 border border-red-500/50 text-red-500 hover:bg-red-500/20 transition-all uppercase tracking-widest text-xs"
            >
              <XCircle size={18} /> Kill Link
            </button>
           )}
           <button 
            onClick={() => fileInputRef.current?.click()}
            className="p-4 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 transition-colors"
           >
             <Upload size={20} />
           </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-6 overflow-hidden">
        <div className="rounded-[2.5rem] border border-white/10 bg-black relative overflow-hidden shadow-2xl group flex flex-col">
          {showGame && result?.html ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute inset-0 z-50 bg-black"
            >
               <iframe srcDoc={result.html} className="w-full h-full border-none" title="Simulation Output" />
               <button 
                onClick={() => setShowGame(false)}
                className="absolute top-6 right-6 bg-black/60 backdrop-blur-md p-3 rounded-full hover:bg-white/10 border border-white/10"
               >
                <XCircle size={24} className="text-white" />
               </button>
            </motion.div>
          ) : !isCameraActive ? (
            <div className="flex-1 flex flex-col items-center justify-center">
              {mode === AppMode.CREATOR ? (
                <TiltWrapper color={color}>
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="flex flex-col items-center gap-8"
                  >
                    <motion.div
                      animate={{ 
                        y: [0, -10, 0],
                        rotate: [0, 5, -5, 0]
                      }}
                      transition={{ duration: 4, repeat: Infinity }}
                      className="p-8 rounded-full bg-white/5 border border-white/10 shadow-inner"
                    >
                      <Layers size={64} style={{ color: color }} />
                    </motion.div>
                    <div className="space-y-2">
                      <h3 className="text-2xl font-black uppercase tracking-tighter">Manifest Sketch</h3>
                      <p className="text-sm opacity-50 font-medium max-w-xs uppercase tracking-widest leading-relaxed">
                        Drop your visual concepts here to begin neural synthesis.
                      </p>
                    </div>
                    <motion.div 
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-8 py-3 rounded-xl font-bold uppercase tracking-[0.2em] text-[10px] border border-white/10 bg-white/5 group-hover:bg-white/10 transition-colors"
                    >
                      Upload_Geometry
                    </motion.div>
                  </div>
                </TiltWrapper>
              ) : (
                <div className="flex flex-col items-center gap-4 opacity-30">
                  <Compass size={80} className="animate-pulse" />
                  <p className="text-xs font-black uppercase tracking-[0.5em] italic">Awaiting_Neural_Link</p>
                </div>
              )}
            </div>
          ) : (
            <div className="flex-1 relative">
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover grayscale brightness-75 contrast-125" />
              <canvas ref={overlayRef} className="absolute inset-0 w-full h-full pointer-events-none z-10" />
              
              <div className="absolute top-8 left-8 flex items-center gap-4 z-20">
                 <div className="bg-red-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest text-white flex items-center gap-2 shadow-lg">
                    <div className="w-2 h-2 rounded-full bg-white animate-ping" /> {isAnalyzing ? 'DECODING_REALITY' : 'NEURAL_ACTIVE'}
                 </div>
              </div>

              <AnimatePresence>
                {isAnalyzing && mode === AppMode.CREATOR && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 z-40 flex items-center justify-center bg-black/90 backdrop-blur-2xl"
                  >
                    <div className="relative flex flex-col items-center">
                      <div className="relative w-72 h-72 flex items-center justify-center">
                        {[
                          { icon: <Code />, color: '#7CFF00', delay: 0 },
                          { icon: <Braces />, color: '#00E5FF', delay: 1.5 },
                          { icon: <Terminal />, color: '#A855F7', delay: 3 },
                          { icon: <Cpu />, color: '#F472B6', delay: 4.5 }
                        ].map((item, idx) => (
                          <motion.div
                            key={idx}
                            className="absolute"
                            animate={{ rotate: 360 }}
                            transition={{ duration: 8, repeat: Infinity, ease: "linear", delay: item.delay }}
                            style={{ width: '100%', height: '100%' }}
                          >
                            <motion.div 
                              className="absolute top-0 left-1/2 -translate-x-1/2 p-4 rounded-2xl bg-white/5 border border-white/10 shadow-2xl backdrop-blur-md"
                              style={{ color: item.color }}
                              animate={{ rotate: -360, scale: [1, 1.1, 1] }}
                              transition={{ duration: 8, repeat: Infinity, ease: "linear", delay: item.delay }}
                            >
                              {item.icon}
                            </motion.div>
                          </motion.div>
                        ))}

                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
                          className="relative z-10 p-12 rounded-[3rem] bg-accent1/10 border border-accent1/40 shadow-[0_0_100px_rgba(124,255,0,0.2)] flex flex-col items-center gap-4"
                        >
                          <Palette className="w-20 h-20 text-accent1" />
                        </motion.div>
                        
                        {[1, 2].map((r) => (
                          <motion.div
                            key={r}
                            initial={{ scale: 0.5, opacity: 0 }}
                            animate={{ scale: 2, opacity: [0, 0.3, 0] }}
                            transition={{ duration: 4, repeat: Infinity, delay: r * 2 }}
                            className="absolute inset-0 border border-white/10 rounded-full"
                          />
                        ))}
                      </div>

                      <div className="mt-16 text-center space-y-4">
                        <motion.h3 
                          animate={{ opacity: [0.4, 1, 0.4] }}
                          transition={{ duration: 2, repeat: Infinity }}
                          className="text-4xl font-black uppercase tracking-[0.4em] text-white italic"
                        >
                          Manifesting_Logic
                        </motion.h3>
                        <div className="flex gap-2 justify-center">
                          {[0, 1, 2, 3].map(dot => (
                            <motion.div
                              key={dot}
                              animate={{ y: [0, -10, 0] }}
                              transition={{ duration: 1, repeat: Infinity, delay: dot * 0.2 }}
                              className="w-2 h-2 rounded-full bg-accent1"
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20">
                <button 
                  onClick={captureAndAnalyze}
                  disabled={isAnalyzing}
                  className="group relative px-14 py-7 rounded-[2.5rem] font-black text-2xl flex items-center gap-5 transition-all hover:scale-105 active:scale-95 disabled:opacity-50 overflow-hidden shadow-2xl"
                  style={{ backgroundColor: colors.accent2, color: colors.primary }}
                >
                  <div className="absolute inset-0 bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 skew-x-12" />
                  {isAnalyzing ? <Loader2 className="animate-spin" size={32} /> : <Sparkles size={32} />}
                  {isAnalyzing ? 'SYNCING...' : 'SENSE REALITY'}
                </button>
              </div>
            </div>
          )}
          <canvas ref={canvasRef} className="hidden" />
        </div>

        <div className="rounded-[2.5rem] border border-white/10 flex flex-col overflow-hidden shadow-2xl backdrop-blur-xl"
             style={{ backgroundColor: colors.card, borderColor: colors.border }}>
          
          <div className="p-8 border-b flex items-center justify-between" style={{ borderColor: colors.border }}>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 shadow-inner">
                <Activity className="text-accent1" size={28} /> 
              </div>
              <div>
                <h3 className="font-black text-2xl tracking-tighter uppercase">{title} Engine</h3>
                <p className="text-[10px] font-bold opacity-30 tracking-[0.3em]">VERSION_3.1_MULTIMODAL_CORE</p>
              </div>
            </div>
          </div>
          
          <div className="flex-1 p-10 overflow-y-auto space-y-12 custom-scrollbar scroll-smooth">
            <AnimatePresence mode="wait">
              {!result && !isAnalyzing ? (
                <motion.div 
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  className="h-full flex flex-col items-center justify-center text-center opacity-20 space-y-6"
                >
                  <Box size={100} strokeWidth={1} />
                  <div className="space-y-2">
                    <p className="text-2xl font-black uppercase tracking-[0.4em]">Signal_Required</p>
                    <p className="font-medium max-w-xs mx-auto">Initiate sensory link to populate analytical data streams.</p>
                  </div>
                </motion.div>
              ) : isAnalyzing ? (
                <div className="space-y-12">
                  {[1,2,3].map(i => (
                    <div key={i} className="animate-pulse space-y-4">
                      <div className="h-4 w-48 bg-white/10 rounded-full" />
                      <div className="h-44 w-full bg-white/5 rounded-[3rem] border border-white/5" />
                    </div>
                  ))}
                </div>
              ) : (
                <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} className="space-y-16">
                  
                  {mode === AppMode.INVENTOR && result.steps && (
                    <div className="space-y-8">
                      <div className="flex items-center justify-between px-2">
                        <h4 className="text-xs font-black uppercase tracking-[0.4em] opacity-40">AR_PHASE_SEQUENCE</h4>
                        <div className="flex gap-1">
                          {result.steps.map((_: any, i: number) => (
                            <div key={i} className={`h-1 w-6 rounded-full ${i <= currentStep ? 'bg-accent1' : 'bg-white/10'}`} />
                          ))}
                        </div>
                      </div>
                      <div className="grid gap-6">
                        {result.steps.map((step: any, idx: number) => (
                          <motion.button
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: idx * 0.1 }}
                            key={idx}
                            onClick={() => setCurrentStep(idx)}
                            className={`group w-full p-10 rounded-[2.5rem] border transition-all text-left flex items-start gap-8 relative overflow-hidden ${
                              currentStep === idx 
                                ? 'bg-accent1/10 border-accent1 shadow-[0_0_50px_rgba(124,255,0,0.1)]' 
                                : 'bg-white/5 border-white/5 hover:bg-white/10'
                            }`}
                          >
                            <div className={`w-14 h-14 rounded-3xl flex items-center justify-center font-black text-2xl shrink-0 transition-all ${
                              currentStep === idx ? 'bg-accent1 text-black scale-110' : 'bg-white/10 text-white opacity-20'
                            }`}>
                              {idx + 1}
                            </div>
                            <div className="flex-1 space-y-3">
                              <p className={`text-xl font-black tracking-tight leading-none ${currentStep === idx ? 'text-accent1' : 'text-white/70'}`}>
                                {step.step}
                              </p>
                              <div className="flex items-center gap-3">
                                <div className={`w-1.5 h-1.5 rounded-full ${currentStep === idx ? 'bg-accent1 animate-pulse' : 'bg-white/20'}`} />
                                <p className="text-sm opacity-40 font-bold uppercase tracking-widest italic">
                                  AR_GUIDE: {step.ar_tip}
                                </p>
                              </div>
                            </div>
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  )}

                  {mode === AppMode.CREATOR && result.html && (
                    <div className="p-10 rounded-[3rem] bg-accent1/10 border border-accent1/40 flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:opacity-10 transition-opacity">
                        <Sparkles size={120} />
                      </div>
                      <div className="space-y-4 relative z-10">
                        <h4 className="font-black text-3xl italic tracking-tighter uppercase leading-none">Simulation_Ready</h4>
                        <p className="text-sm opacity-50 font-medium max-w-xs">Executable world geometry successfully synthesized from sketch input.</p>
                      </div>
                      <button 
                        onClick={() => setShowGame(true)}
                        className="relative px-12 py-6 bg-accent1 text-black font-black rounded-3xl flex items-center gap-3 hover:scale-105 active:scale-95 transition-transform shadow-[0_0_50px_rgba(124,255,0,0.3)] uppercase tracking-widest text-xs"
                      >
                        <Play size={20} fill="currentColor" /> Initialize World
                      </button>
                    </div>
                  )}

                  {Object.entries(result).map(([key, value]) => {
                    const filteredKeys = ['html', 'pose_overlays', 'live_caption', 'narration', 'steps', 'ingredients', 'recipeName'];
                    if (filteredKeys.includes(key)) return null;
                    
                    return (
                      <div key={key} className="space-y-6">
                        <h4 className="text-[10px] font-black uppercase tracking-[0.5em] mb-4 opacity-30 flex items-center gap-4">
                           <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
                           {key.replace(/([A-Z])/g, ' $1')}
                        </h4>
                        <div className="grid gap-4">
                          {Array.isArray(value) ? (
                            value.map((item: any, idx) => (
                              <motion.div 
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ delay: idx * 0.05 }}
                                key={idx} 
                                className="p-8 rounded-[2rem] border border-white/5 bg-white/5 backdrop-blur-md text-sm leading-relaxed font-bold shadow-sm"
                              >
                                {typeof item === 'string' ? item : (
                                  <div className="grid gap-3">
                                    {Object.entries(item).map(([sk, sv]) => (
                                      <div key={sk} className="flex gap-6 items-baseline">
                                        <span className="text-[9px] font-black text-accent1 uppercase tracking-[0.2em] shrink-0 opacity-60">{sk}:</span>
                                        <span className="opacity-80 italic">{String(sv)}</span>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </motion.div>
                            ))
                          ) : (
                            <div className="p-12 rounded-[3rem] border border-white/5 bg-white/5 flex items-center justify-center text-center shadow-inner">
                              <div className="space-y-4">
                                <div className="text-6xl font-black italic tracking-tighter" style={{ color: color }}>
                                  {typeof value === 'number' ? value : String(value)}
                                  {typeof value === 'number' && key.toLowerCase().includes('score') && '%'}
                                </div>
                                <div className="h-px w-20 bg-white/10 mx-auto" />
                                <p className="text-[10px] font-black uppercase tracking-[0.5em] opacity-30 italic">Metric_Index_001</p>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="p-8 bg-black/40 border-t flex items-center justify-around text-[10px] font-black uppercase tracking-[0.4em] backdrop-blur-3xl" style={{ borderColor: colors.border }}>
            <span className="flex items-center gap-3 text-accent1/40 hover:text-accent1 transition-colors cursor-help"><Cpu size={14} /> G3_NEURAL_TURBO</span>
            <span className="flex items-center gap-3 text-accent2/40 hover:text-accent2 transition-colors cursor-help"><Activity size={14} /> LATENCY: 14MS</span>
            <span className="flex items-center gap-3 text-accent1/40 hover:text-accent1 transition-colors cursor-help"><Target size={14} /> LINK_STABILITY: 100%</span>
          </div>
        </div>
      </div>
      
      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-12 left-1/2 -translate-x-1/2 bg-red-600/90 backdrop-blur-2xl text-white px-12 py-6 rounded-3xl shadow-[0_0_80px_rgba(220,38,38,0.3)] flex items-center gap-5 z-[100] font-black uppercase tracking-[0.2em] text-[10px] border border-white/20"
          >
            <Info size={24} /> SIGNAL_FRAGMENTATION: {error}
            <button onClick={() => setError(null)} className="ml-6 p-2 hover:bg-white/10 rounded-full transition-colors">
              <XCircle size={20} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FeatureMode;
