
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, 
  X, 
  Sun, 
  Moon, 
  Bell, 
  User as UserIcon,
  LogOut,
  ChevronRight
} from 'lucide-react';
import { AppMode, Theme, User } from '../types';
import { MODES, NAV_ITEMS, THEMES } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  activeMode: AppMode;
  onModeChange: (mode: AppMode) => void;
  theme: Theme;
  toggleTheme: () => void;
  user: User | null;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  activeMode, 
  onModeChange, 
  theme, 
  toggleTheme, 
  user,
  onLogout 
}) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const colors = THEMES[theme];

  return (
    <div 
      className="min-h-screen flex transition-colors duration-500 overflow-hidden"
      style={{ backgroundColor: colors.primary, color: colors.text }}
    >
      {/* Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: sidebarOpen ? 280 : 80 }}
        className="relative border-r z-50 flex flex-col"
        style={{ borderColor: colors.border, backgroundColor: colors.secondary }}
      >
        <div className="p-6 flex items-center justify-between">
          {sidebarOpen ? (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="flex items-center gap-2"
            >
              <div className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xl"
                   style={{ backgroundColor: colors.accent1, color: colors.primary }}>
                M
              </div>
              <span className="font-bold text-xl tracking-tighter uppercase italic">MUSES</span>
            </motion.div>
          ) : (
             <div className="w-8 h-8 mx-auto rounded-lg flex items-center justify-center font-bold text-xl"
                  style={{ backgroundColor: colors.accent1, color: colors.primary }}>
              M
            </div>
          )}
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => onModeChange(item.id)}
              className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all duration-200 group relative
                ${activeMode === item.id ? 'shadow-lg' : 'hover:bg-white/5'}`}
              style={{
                backgroundColor: activeMode === item.id ? colors.accent1 : 'transparent',
                color: activeMode === item.id ? colors.primary : colors.text
              }}
            >
              <div className={`${activeMode === item.id ? 'text-primary' : 'text-accent'}`} 
                   style={{ color: activeMode === item.id ? colors.primary : colors.accent2 }}>
                {item.icon}
              </div>
              {sidebarOpen && <span className="font-medium">{item.label}</span>}
              {!sidebarOpen && (
                <div className="absolute left-full ml-4 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                  {item.label}
                </div>
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t" style={{ borderColor: colors.border }}>
           <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full flex items-center justify-center p-2 rounded-lg hover:bg-white/5"
            style={{ color: colors.text }}
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-y-auto relative">
        {/* Top Header */}
        <header 
          className="sticky top-0 z-40 px-8 py-4 flex items-center justify-between border-b backdrop-blur-md"
          style={{ borderColor: colors.border, backgroundColor: `${colors.primary}CC` }}
        >
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium opacity-50">System</span>
            <ChevronRight size={14} className="opacity-50" />
            <span className="text-sm font-bold tracking-widest uppercase">
              {activeMode}
            </span>
          </div>

          <div className="flex items-center gap-6">
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
              style={{ color: colors.text }}
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            
            <div className="h-6 w-px bg-white/10" />

            {user ? (
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-bold">{user.name}</p>
                  <p className="text-xs opacity-50">{user.email}</p>
                </div>
                <div className="relative group">
                  <div className="w-10 h-10 rounded-full border-2 border-accent1 p-0.5 overflow-hidden">
                    <img 
                      src={user.avatar || `https://picsum.photos/seed/${user.id}/100`} 
                      className="w-full h-full rounded-full object-cover" 
                      alt="avatar" 
                    />
                  </div>
                  <div className="absolute right-0 top-full mt-2 w-48 py-2 rounded-xl shadow-2xl border hidden group-hover:block z-50"
                       style={{ backgroundColor: colors.secondary, borderColor: colors.border }}>
                    <button 
                      onClick={onLogout}
                      className="w-full px-4 py-2 flex items-center gap-2 hover:bg-white/5 text-red-400 text-sm font-medium"
                    >
                      <LogOut size={16} /> Logout
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <button 
                onClick={() => onModeChange(AppMode.HOME)}
                className="px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2"
                style={{ backgroundColor: colors.accent1, color: colors.primary }}
              >
                Sign In
              </button>
            )}
          </div>
        </header>

        <section className="flex-1 p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeMode}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </section>
      </main>
    </div>
  );
};

export default Layout;
