
import React from 'react';
import { motion } from 'framer-motion';
import { 
  Activity, 
  BarChart3, 
  Clock, 
  Cpu, 
  Play, 
  Sparkles, 
  TrendingUp,
  Brain
} from 'lucide-react';
import { Theme, AppMode, User } from '../types';
import { THEMES, MODES } from '../constants';

interface DashboardProps {
  theme: Theme;
  user: User | null;
  onModeSelect: (mode: AppMode) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ theme, user, onModeSelect }) => {
  const colors = THEMES[theme];

  const stats = [
    { label: 'Real-time Feed', value: 'Active', icon: <Clock size={16} />, color: '#10B981' },
    { label: 'AI Confidence', value: '98.4%', icon: <Brain size={16} />, color: '#3B82F6' },
    { label: 'Processing', value: '14ms', icon: <Cpu size={16} />, color: '#A855F7' },
    { label: 'Daily Goals', value: '4 / 5', icon: <Target size={16} />, color: '#F59E0B' }
  ];

  return (
    <div className="h-full flex flex-col gap-8 pb-10">
      <header className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
          <h1 className="text-4xl font-black mb-2">Welcome back, {user?.name.split(' ')[0] || 'Explorer'}</h1>
          <p className="opacity-60 text-lg">System status: <span className="text-green-400 font-bold">Optimized</span>. All reality sensors are online.</p>
        </div>
        <div className="flex gap-4">
          <button className="px-6 py-3 rounded-xl bg-white/5 border border-white/10 font-bold text-sm hover:bg-white/10 transition-all">
            View Analytics
          </button>
          <button className="px-6 py-3 rounded-xl font-bold text-sm flex items-center gap-2 shadow-lg hover:scale-105 transition-all"
                  style={{ backgroundColor: colors.accent1, color: colors.primary }}>
            <Sparkles size={16} /> Quick Action
          </button>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="p-6 rounded-3xl border border-white/10 flex flex-col gap-3"
            style={{ backgroundColor: colors.card }}
          >
            <div className="flex items-center justify-between opacity-50">
              <span className="text-xs font-bold uppercase tracking-widest">{stat.label}</span>
              {stat.icon}
            </div>
            <div className="text-3xl font-black" style={{ color: stat.color }}>{stat.value}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Core Modes Selection */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Select Active Engine</h2>
            <button className="text-sm font-bold text-accent1 flex items-center gap-1 opacity-70">
              Settings <ArrowRight size={14} />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MODES.map((mode, i) => (
              <motion.button
                key={mode.id}
                whileHover={{ scale: 1.02, x: 5 }}
                onClick={() => onModeSelect(mode.id)}
                className="group p-6 rounded-3xl border border-white/10 text-left transition-all relative overflow-hidden flex items-center gap-6"
                style={{ backgroundColor: colors.card }}
              >
                <div 
                  className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-inner shrink-0"
                  style={{ backgroundColor: `${mode.color}15`, color: mode.color }}
                >
                  {mode.icon}
                </div>
                <div>
                  <h3 className="text-xl font-bold">{mode.label}</h3>
                  <p className="text-sm opacity-60 leading-tight">{mode.description.slice(0, 60)}...</p>
                </div>
                <div className="absolute top-0 right-0 w-32 h-32 blur-3xl opacity-0 group-hover:opacity-10 transition-opacity pointer-events-none"
                     style={{ backgroundColor: mode.color }} />
              </motion.button>
            ))}
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-6">
          <div className="p-6 rounded-3xl border border-white/10 flex flex-col gap-6"
               style={{ backgroundColor: colors.card }}>
            <h2 className="text-xl font-bold flex items-center gap-2"><Activity size={20} className="text-green-400" /> Recent Activity</h2>
            <div className="space-y-4">
              {[
                { title: 'Cricket Swing Analysis', time: '2h ago', mode: 'COACH' },
                { title: 'Fridge Inventory Scanned', time: '5h ago', mode: 'INVENTOR' },
                { title: 'Mock Interview Feedback', time: 'Yesterday', mode: 'WINGMAN' }
              ].map((act, i) => (
                <div key={i} className="flex items-center gap-4 group cursor-pointer">
                  <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0 border border-white/5">
                    <Play size={14} className="group-hover:text-accent1 transition-colors" />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-sm font-bold truncate">{act.title}</p>
                    <p className="text-xs opacity-40">{act.mode} • {act.time}</p>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full py-3 rounded-xl bg-white/5 border border-white/10 text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-colors">
              View All History
            </button>
          </div>

          <div className="p-6 rounded-3xl border border-white/10 bg-gradient-to-br from-indigo-900/40 to-purple-900/40 backdrop-blur-xl relative overflow-hidden group border-indigo-500/30">
            <div className="relative z-10">
              <h3 className="font-black text-xl mb-2 flex items-center gap-2">
                <Sparkles size={18} className="text-yellow-400" /> Upgrade to Pro
              </h3>
              <p className="text-sm opacity-80 mb-6">Unlock Gemini 3 Pro reasoning and unlimited 4K video analysis.</p>
              <button className="w-full py-3 rounded-xl bg-white text-black font-black text-xs uppercase tracking-widest shadow-xl group-hover:scale-[1.02] transition-transform">
                Get Started
              </button>
            </div>
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-indigo-500/20 blur-[60px]" />
          </div>
        </div>
      </div>
    </div>
  );
};

const Target = ({ size, className }: { size: number, className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="6" /><circle cx="12" cy="12" r="2" />
  </svg>
);

const ArrowRight = ({ size, className }: { size: number, className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M5 12h14" /><path d="m12 5 7 7-7 7" />
  </svg>
);

export default Dashboard;
