
import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Play, ArrowRight, Shield, Globe, Cpu } from 'lucide-react';
import { Theme, AppMode } from '../types';
import { THEMES, MODES } from '../constants';

interface HomeProps {
  onStart: (guest: boolean) => void;
  theme: Theme;
  toggleTheme: () => void;
}

const Home: React.FC<HomeProps> = ({ onStart, theme, toggleTheme }) => {
  const colors = THEMES[theme];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: colors.primary, color: colors.text }}>
      {/* Background Animated Elements */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div 
          className="absolute top-0 right-0 w-[800px] h-[800px] rounded-full blur-[150px] opacity-20"
          style={{ background: `radial-gradient(circle, ${colors.accent2}, transparent)` }}
        />
        <div 
          className="absolute bottom-0 left-0 w-[600px] h-[600px] rounded-full blur-[150px] opacity-20"
          style={{ background: `radial-gradient(circle, ${colors.glow}, transparent)` }}
        />
        {/* Particle Overlay would go here */}
      </div>

      {/* Nav */}
      <nav className="relative z-10 px-10 py-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-2xl shadow-lg"
               style={{ backgroundColor: colors.accent1, color: colors.primary }}>
            M
          </div>
          <span className="text-2xl font-black tracking-tight uppercase italic">MUSES</span>
        </div>
        <div className="flex items-center gap-8">
          <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-white/10">
            {theme === 'dark' ? <Zap className="text-yellow-400" /> : <Zap className="text-blue-600" />}
          </button>
          <button 
            onClick={() => onStart(false)}
            className="px-6 py-2.5 rounded-full font-bold transition-transform hover:scale-105"
            style={{ backgroundColor: colors.accent1, color: colors.primary }}
          >
            Sign In
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 px-10 pt-20 pb-40 max-w-7xl mx-auto flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/10 mb-8 bg-white/5 backdrop-blur-sm"
        >
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-xs font-bold uppercase tracking-widest opacity-70">Gemini 3 Powered Reality Engine</span>
        </motion.div>

        <motion.h1 
          className="text-7xl md:text-9xl font-black mb-6 leading-tight"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Your Reality <br />
          <span className="text-transparent bg-clip-text" style={{ backgroundImage: `linear-gradient(to right, ${colors.accent1}, ${colors.accent2})` }}>
            Co-Pilot
          </span>
        </motion.h1>

        <motion.p 
          className="text-xl md:text-2xl opacity-60 max-w-3xl mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          See. Think. Predict. Create. MUSES integrates multimodal intelligence into your daily life, transforming how you perceive and interact with the physical world.
        </motion.p>

        <motion.div 
          className="flex flex-wrap justify-center gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <button 
            onClick={() => onStart(true)}
            className="group px-8 py-4 rounded-2xl font-black text-lg flex items-center gap-3 transition-all hover:scale-105 shadow-[0_0_30px_rgba(124,255,0,0.3)]"
            style={{ backgroundColor: colors.accent1, color: colors.primary }}
          >
            Start as Guest <ArrowRight className="group-hover:translate-x-1 transition-transform" />
          </button>
          <button 
            className="px-8 py-4 rounded-2xl font-black text-lg border border-white/10 bg-white/5 backdrop-blur-md hover:bg-white/10 transition-all"
          >
            View Documentation
          </button>
        </motion.div>

        {/* Floating Visual Mock */}
        <motion.div 
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, type: 'spring' }}
          className="mt-32 w-full max-w-5xl rounded-3xl border border-white/10 overflow-hidden shadow-2xl relative group"
          style={{ backgroundColor: colors.secondary }}
        >
          <img src="https://picsum.photos/seed/muses_hero/1200/600" alt="Interface" className="w-full opacity-60 grayscale group-hover:grayscale-0 transition-all duration-1000" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0F1E] to-transparent" />
          <div className="absolute bottom-10 left-10 text-left">
            <h3 className="text-3xl font-black mb-2">Multimodal Core</h3>
            <p className="opacity-70">Processing vision, audio, and sensor data in 14ms.</p>
          </div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full bg-white/20 backdrop-blur-xl flex items-center justify-center cursor-pointer hover:scale-110 transition-transform border border-white/30">
            <Play fill="white" size={32} />
          </div>
        </motion.div>
      </section>

      {/* Features Grid */}
      <section className="px-10 py-40 max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <h2 className="text-5xl font-black mb-4">Five Modes of Intelligence</h2>
          <p className="opacity-60 text-lg">A specialized engine for every aspect of reality.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {MODES.map((mode, i) => (
            <motion.div
              key={mode.id}
              whileHover={{ y: -10, scale: 1.02 }}
              className="p-8 rounded-3xl border border-white/10 backdrop-blur-md transition-all h-full flex flex-col"
              style={{ backgroundColor: colors.card }}
            >
              <div 
                className="w-14 h-14 rounded-2xl mb-6 flex items-center justify-center shadow-lg"
                style={{ backgroundColor: `${mode.color}20`, color: mode.color }}
              >
                {mode.icon}
              </div>
              <h3 className="text-2xl font-bold mb-2">{mode.label}</h3>
              <p className="text-sm font-bold uppercase tracking-widest mb-4 opacity-50">{mode.tagline}</p>
              <p className="opacity-70 leading-relaxed mb-8 flex-1">{mode.description}</p>
              <div className="flex items-center gap-2 font-bold text-sm cursor-pointer group" style={{ color: mode.color }}>
                Explore Mode <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="px-10 py-20 border-t" style={{ borderColor: colors.border }}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-lg"
                 style={{ backgroundColor: colors.accent1, color: colors.primary }}>
              M
            </div>
            <span className="text-lg font-black tracking-tight italic">MUSES</span>
          </div>
          <div className="flex gap-10 opacity-60 font-medium">
            <a href="#" className="hover:text-white transition-colors">About</a>
            <a href="#" className="hover:text-white transition-colors">Docs</a>
            <a href="#" className="hover:text-white transition-colors">GitHub</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
          </div>
          <p className="text-sm opacity-40">© 2024 MUSES Engine. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
};

const ChevronRight = ({ size, className }: { size: number, className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="m9 18 6-6-6-6" />
  </svg>
);

export default Home;
