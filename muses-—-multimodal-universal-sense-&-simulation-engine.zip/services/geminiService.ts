
import { GoogleGenAI, Type, Modality } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeScene = async (imageB64: string, mode: string, customPrompt?: string) => {
  const ai = getAI();
  const model = 'gemini-3-flash-preview';
  
  const systemInstructions: Record<string, string> = {
    FUTURE: `You are the Future Mode engine. Analyze the image and predict likely next events. 
    Return JSON: { 
      "predictions": ["string"], 
      "risks": [{"label": "string", "severity": "low|med|high", "box_2d": [ymin, xmin, ymax, xmax]}],
      "narration": "A concise sci-fi style summary of the scene."
    }`,
    COACH: `You are the Coach Mode engine. Analyze posture and motion. 
    Return JSON: {
      "postureScore": number,
      "feedback": "string",
      "pose_overlays": [{"type": "line|angle", "points": [[y,x]], "label": "string"}],
      "drills": ["string"]
    }`,
    CREATOR: `You are the Creator Mode engine. Convert the sketch into a single-file HTML/JS game. 
    Return JSON: {
      "title": "string",
      "html": "Complete HTML source with script and styles included",
      "controls": "string"
    }`,
    WINGMAN: `You are the Wingman Mode engine. Analyze appearance and body language for an interview. 
    Return JSON: {
      "confidence": number,
      "positivity": number,
      "tips": ["string"],
      "live_caption": "Suggested next thing to say"
    }`,
    INVENTOR: `You are the Inventor Mode engine. Identify ingredients from the image and suggest a recipe. 
    Return JSON: {
      "recipeName": "string",
      "ingredients": [{"name": "string", "box_2d": [ymin, xmin, ymax, xmax]}],
      "steps": [{"step": "string", "ar_tip": "visual guide description", "relevant_ingredient_index": number}]
    }`
  };

  const prompt = customPrompt || "Execute specialized multimodal analysis.";

  try {
    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          { inlineData: { data: imageB64, mimeType: 'image/jpeg' } },
          { text: prompt }
        ]
      },
      config: {
        systemInstruction: systemInstructions[mode] || "Analyze the provided image.",
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const generateSpeech = async (text: string, voice: string = 'Kore') => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) return null;

    return base64Audio;
  } catch (error) {
    console.error("TTS Error:", error);
    return null;
  }
};

export const playAudio = async (base64Audio: string) => {
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const audioBuffer = await decodeAudioData(decode(base64Audio), audioContext, 24000, 1);
  const source = audioContext.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(audioContext.destination);
  source.start();
};
