
import React, { useState, useEffect } from 'react';
import { AppMode, Theme, User } from './types';
import Layout from './components/Layout';
import Home from './views/Home';
import Dashboard from './views/Dashboard';
import FeatureMode from './components/FeatureMode';
import { MODES } from './constants';

const App: React.FC = () => {
  const [activeMode, setActiveMode] = useState<AppMode>(AppMode.HOME);
  const [theme, setTheme] = useState<Theme>('dark');
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedTheme = localStorage.getItem('muses-theme') as Theme;
    if (savedTheme) setTheme(savedTheme);
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    localStorage.setItem('muses-theme', newTheme);
  };

  const handleStart = (guest: boolean) => {
    if (guest) {
      setUser({
        id: 'guest',
        name: 'Guest User',
        email: 'guest@muses.ai'
      });
    } else {
      // For demo purposes, we auto-sign in
       setUser({
        id: 'user_123',
        name: 'Alex Rivera',
        email: 'alex@deepmind.com',
        avatar: 'https://picsum.photos/seed/alex/100'
      });
    }
    setActiveMode(AppMode.DASHBOARD);
  };

  const handleLogout = () => {
    setUser(null);
    setActiveMode(AppMode.HOME);
  };

  // View Router
  const renderContent = () => {
    if (activeMode === AppMode.HOME) {
      return <Home onStart={handleStart} theme={theme} toggleTheme={toggleTheme} />;
    }

    // Wrap internal views in Layout
    return (
      <Layout 
        activeMode={activeMode} 
        onModeChange={setActiveMode} 
        theme={theme} 
        toggleTheme={toggleTheme}
        user={user}
        onLogout={handleLogout}
      >
        {(() => {
          switch (activeMode) {
            case AppMode.DASHBOARD:
              return <Dashboard theme={theme} user={user} onModeSelect={setActiveMode} />;
            
            case AppMode.FUTURE:
            case AppMode.COACH:
            case AppMode.CREATOR:
            case AppMode.WINGMAN:
            case AppMode.INVENTOR:
              const modeConfig = MODES.find(m => m.id === activeMode)!;
              return (
                <FeatureMode 
                  mode={activeMode}
                  theme={theme}
                  title={modeConfig.label}
                  tagline={modeConfig.tagline}
                  description={modeConfig.description}
                  icon={modeConfig.icon}
                  color={modeConfig.color}
                />
              );

            case AppMode.SETTINGS:
              return (
                <div className="max-w-4xl mx-auto space-y-12">
                   <h1 className="text-4xl font-black">System Preferences</h1>
                   <div className="space-y-6">
                     <section className="p-8 rounded-3xl border border-white/10 bg-white/5">
                        <h2 className="text-xl font-bold mb-6">Reality Sensors</h2>
                        <div className="space-y-4">
                           <div className="flex items-center justify-between">
                              <div>
                                <p className="font-bold">Multimodal Capture</p>
                                <p className="text-sm opacity-50">High-fidelity vision and audio processing.</p>
                              </div>
                              <div className="w-12 h-6 bg-green-500 rounded-full relative p-1 cursor-pointer">
                                <div className="w-4 h-4 bg-white rounded-full ml-auto" />
                              </div>
                           </div>
                        </div>
                     </section>
                   </div>
                </div>
              );
            default:
              return <div>Section under construction</div>;
          }
        })()}
      </Layout>
    );
  };

  return (
    <div className={`theme-${theme} h-screen`}>
      {renderContent()}
    </div>
  );
};

export default App;
