
export enum AppMode {
  HOME = 'HOME',
  DASHBOARD = 'DASHBOARD',
  FUTURE = 'FUTURE',
  COACH = 'COACH',
  CREATOR = 'CREATOR',
  WINGMAN = 'WINGMAN',
  INVENTOR = 'INVENTOR',
  SETTINGS = 'SETTINGS'
}

export type Theme = 'dark' | 'light';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface AnalysisResult {
  id: string;
  timestamp: number;
  type: AppMode;
  summary: string;
  details: any;
}
