
import React from 'react';
import { 
  Zap, 
  Target, 
  Palette, 
  Headphones, 
  ChefHat, 
  LayoutDashboard, 
  Settings,
  Eye,
  Activity,
  Sparkles,
  Brain
} from 'lucide-react';
import { AppMode } from './types';

export const THEMES = {
  dark: {
    primary: '#0A0F1E',
    secondary: '#0F172A',
    accent1: '#7CFF00', // Neon lime
    accent2: '#00E5FF', // Electric cyan
    glow: '#A855F7',   // Neon purple
    text: '#F8FAFC',
    card: 'rgba(15, 23, 42, 0.7)',
    border: 'rgba(255, 255, 255, 0.1)'
  },
  light: {
    primary: '#FFFFFF',
    secondary: '#F1F5F9',
    accent1: '#2563EB',
    accent2: '#16A34A',
    glow: '#9333EA',
    text: '#0F172A',
    card: 'rgba(255, 255, 255, 0.8)',
    border: 'rgba(0, 0, 0, 0.05)'
  }
};

export interface ModeConfig {
  id: AppMode;
  label: string;
  icon: React.ReactNode;
  description: string;
  color: string;
  tagline: string;
}

export const MODES: ModeConfig[] = [
  {
    id: AppMode.FUTURE,
    label: 'Future Mode',
    tagline: 'World Simulator',
    icon: <Eye className="w-6 h-6" />,
    description: 'Predict outcomes, highlight risks, and simulate real-world events through the predictive lens of Gemini 3.',
    color: '#00E5FF'
  },
  {
    id: AppMode.COACH,
    label: 'Coach Mode',
    tagline: 'Sports & Skill Trainer',
    icon: <Activity className="w-6 h-6" />,
    description: 'Live postural analysis and biometric feedback using computer vision to optimize your physical performance.',
    color: '#7CFF00'
  },
  {
    id: AppMode.CREATOR,
    label: 'Creator Mode',
    tagline: 'Sketch to Interactive World',
    icon: <Palette className="w-6 h-6" />,
    description: 'Snap a photo of any drawing and witness MUSES transform it into a playable game or interactive metaverse scene.',
    color: '#A855F7'
  },
  {
    id: AppMode.WINGMAN,
    label: 'Wingman Mode',
    tagline: 'Intelligence Partner',
    icon: <Headphones className="w-6 h-6" />,
    description: 'Your real-time interview and social wingman. Analyzes tone, body language, and provides instant guidance.',
    color: '#F472B6'
  },
  {
    id: AppMode.INVENTOR,
    label: 'Inventor Mode',
    tagline: 'AR Culinary Engine',
    icon: <ChefHat className="w-6 h-6" />,
    description: 'Scan your environment or inventory to synthesize hyper-personalized recipes with interactive AR step guides.',
    color: '#FB923C'
  }
];

export const NAV_ITEMS = [
  { id: AppMode.DASHBOARD, label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
  ...MODES.map(m => ({ id: m.id, label: m.label, icon: m.icon })),
  { id: AppMode.SETTINGS, label: 'Settings', icon: <Settings className="w-5 h-5" /> }
];
